﻿namespace MedicalInterface.Mml23.MmlPc
{
    using System;
    using System.Collections.Generic;
    using System.Xml;

    public class SubjectiveItem
    {
        public string NameSpaceURI
        {
            get
            {
                return ProgressCourseModule.NameSpaceURI;
            }
        }

        public string NameSpacePrefix
        {
            get
            {
                return ProgressCourseModule.NameSpacePrefix;
            }
        }

        public String TimeExpression { get; set; }

        public List<String> EventExpression { get; set; }

        public SubjectiveItem()
        {
            this.EventExpression = new List<string>();
        }

        public SubjectiveItem(XmlNode node)
        {
            this.EventExpression = new List<string>();
            LoadFromXml(node);
        }

        public void LoadFromXml(XmlNode node)
        {
            this.EventExpression = new List<string>();
            foreach (XmlNode elm in node.ChildNodes)
            {
                if (elm.LocalName == "timeExpression")
                {
                    this.TimeExpression = elm.InnerText;
                }

                if (elm.LocalName == "eventExpression")
                {
                    this.EventExpression.Add(elm.InnerText);
                }
            }
        }

        public XmlNode WriteXml(XmlDocument doc)
        {
            XmlElement node = doc.CreateElement(NameSpacePrefix, "subjectiveItem", NameSpaceURI);

            XmlElement elm;

            if (!string.IsNullOrEmpty(TimeExpression))
            {
                elm = doc.CreateElement(NameSpacePrefix, "timeExpression", NameSpaceURI);
                elm.AppendChild(doc.CreateTextNode(this.TimeExpression));
                node.AppendChild(elm);
            }
            
            foreach (String itm in this.EventExpression)
            {
                elm = doc.CreateElement(NameSpacePrefix, "eventExpression", NameSpaceURI);
                elm.AppendChild(doc.CreateTextNode(itm));
                node.AppendChild(elm);
            }
            return node;
        }
    }
}