﻿namespace MedicalInterface.Mml23.MmlPc
{
    using System;
    using System.Collections.Generic;
    using System.Xml;

    public class Plan
    {
        public string NameSpaceURI
        {
            get
            {
                return ProgressCourseModule.NameSpaceURI;
            }
        }

        public string NameSpacePrefix
        {
            get
            {
                return ProgressCourseModule.NameSpacePrefix;
            }
        }

        public String PlanNotes { get; set; }

        public RxTxTestItem TestOrder { get; set; }

        public RxTxTestItem TxOrder { get; set; }

        public RxTxTestItem RxOrder { get; set; }

        public Plan()
        {
        }

        public Plan(XmlNode node)
        {
            LoadFromXml(node);
        }

        public void LoadFromXml(XmlNode node)
        {
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(node.OwnerDocument.NameTable);
            nsmgr.AddNamespace(NameSpacePrefix, NameSpaceURI);

            foreach (XmlNode elm in node.ChildNodes)
            {
                if (elm.LocalName == "planNotes")
                {
                    this.PlanNotes = elm.InnerText;
                }
                if (elm.LocalName == "testOrder")
                {
                    this.TestOrder = new RxTxTestItem(elm);
                }
                if (elm.LocalName == "rxOrder")
                {
                    this.RxOrder = new RxTxTestItem(elm);
                }
                if (elm.LocalName == "txOrder")
                {
                    this.TxOrder = new RxTxTestItem(elm);
                }
            }
        }

        public XmlElement WriteXml(XmlDocument doc)
        {
            XmlElement node = doc.CreateElement(NameSpacePrefix, "plan", NameSpaceURI);

            XmlElement elm;

            if (!string.IsNullOrEmpty(PlanNotes))
            {
                elm = doc.CreateElement(NameSpacePrefix, "planNotes", NameSpaceURI);
                elm.AppendChild(doc.CreateTextNode(this.PlanNotes));
                node.AppendChild(elm);
            }

            if (TestOrder != null)
            {
                node.AppendChild(TestOrder.WriteXml(doc, "testOrder"));
            }

            if (RxOrder != null)
            {
                node.AppendChild(RxOrder.WriteXml(doc, "rxOrder"));
            }

            if (TxOrder != null)
            {
                node.AppendChild(TxOrder.WriteXml(doc, "txOrder"));
            }

            return node;
        }
    }
}