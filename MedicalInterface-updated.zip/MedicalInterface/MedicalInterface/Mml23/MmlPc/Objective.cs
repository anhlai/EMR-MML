﻿namespace MedicalInterface.Mml23.MmlPc
{
    using System;
    using System.Collections.Generic;
    using System.Xml;

    public class Objective
    {
        public string NameSpaceURI
        {
            get
            {
                return ProgressCourseModule.NameSpaceURI;
            }
        }

        public string NameSpacePrefix
        {
            get
            {
                return ProgressCourseModule.NameSpacePrefix;
            }
        }

        public String ObjectiveNotes { get; set; }

        public List<PhysicalExamItem> PhysicalExamContents { get; set; }

        public RxTxTestItem TestResults { get; set; }

        public RxTxTestItem RxRecords { get; set; }

        public RxTxTestItem TxRecords { get; set; }

        public Objective()
        {
            this.PhysicalExamContents = new List<PhysicalExamItem>();
        }

        public Objective(XmlNode node)
        {
            this.PhysicalExamContents = new List<PhysicalExamItem>();
            LoadFromXml(node);
        }

        public void LoadFromXml(XmlNode node)
        {
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(node.OwnerDocument.NameTable);
            nsmgr.AddNamespace(NameSpacePrefix, NameSpaceURI);

            foreach (XmlNode elm in node.ChildNodes)
            {
                if (elm.LocalName == "objectiveNotes")
                {
                    this.ObjectiveNotes = elm.InnerText;
                }
                if (elm.LocalName == "physicalExam")
                {
                    this.PhysicalExamContents = new List<PhysicalExamItem>();
                    foreach (XmlNode dgnode in elm.ChildNodes)
                    {
                        PhysicalExamItem dg = new PhysicalExamItem(dgnode);
                        this.PhysicalExamContents.Add(dg);
                    }                    
                }
                if (elm.LocalName == "testResult")
                {
                    this.TestResults = new RxTxTestItem(elm);
                }
                if (elm.LocalName == "rxRecord")
                {
                    this.RxRecords = new RxTxTestItem(elm);
                }
                if (elm.LocalName == "txRecord")
                {
                    this.TxRecords = new RxTxTestItem(elm);
                }
            }
        }

        public XmlElement WriteXml(XmlDocument doc)
        {
            XmlElement node = doc.CreateElement(NameSpacePrefix, "objective", NameSpaceURI);

            XmlElement elm;

            if (!string.IsNullOrEmpty(ObjectiveNotes))
            {
                elm = doc.CreateElement(NameSpacePrefix, "objectiveNotes", NameSpaceURI);
                elm.AppendChild(doc.CreateTextNode(this.ObjectiveNotes));
                node.AppendChild(elm);
            }

            if (PhysicalExamContents.Count > 0)
            {
                XmlElement dcelm = doc.CreateElement(NameSpacePrefix, "physicalExam", NameSpaceURI);
                foreach (PhysicalExamItem itm in this.PhysicalExamContents)
                {
                    dcelm.AppendChild(itm.WriteXml(doc));
                }
                node.AppendChild(dcelm);
            }

            if (TestResults != null)
            {
                node.AppendChild(TestResults.WriteXml(doc, "testResult"));
            }

            if (RxRecords != null)
            {
                node.AppendChild(RxRecords.WriteXml(doc, "rxRecord"));
            }

            if (TxRecords != null)
            {
                node.AppendChild(TxRecords.WriteXml(doc, "txRecord"));
            }

            return node;
        }
    }
}