﻿namespace MedicalInterface.Mml23.MmlPc
{
    using System;
    using System.Collections.Generic;
    using System.Xml;

    public class ProblemItem
    {
        public string NameSpaceURI
        {
            get
            {
                return ProgressCourseModule.NameSpaceURI;
            }
        }

        public string NameSpacePrefix
        {
            get
            {
                return ProgressCourseModule.NameSpacePrefix;
            }
        }

        public Problem Problem { get; set; }

        public List<String> Assessment { get; set; }

        public Objective Objective { get; set; }

        public Subjective Subjective { get; set; }

        public Plan Plan { get; set; }

        public ProblemItem()
        {
            this.Assessment = new List<string>();
        }

        public ProblemItem(XmlNode node)
        {
            this.Assessment = new List<string>();
            LoadFromXml(node);
        }


        public void LoadFromXml(XmlNode node)
        {
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(node.OwnerDocument.NameTable);
            nsmgr.AddNamespace(NameSpacePrefix, NameSpaceURI);

            foreach (XmlNode elm in node.ChildNodes)
            {
                if (elm.LocalName == "assessment")
                {
                    foreach (XmlNode cn in elm.ChildNodes)
                    {
                        if (cn.LocalName.Equals("assessmentItem"))
                        {
                            this.Assessment.Add(cn.InnerText);
                        }
                    }
                }

                if (elm.LocalName == "problem")
                {
                    this.Problem = new Problem(elm);
                }

                if (elm.LocalName == "subjective")
                {
                    this.Subjective = new Subjective(elm);
                }

                if (elm.LocalName == "objective")
                {
                    this.Objective = new Objective(elm);
                }

                if (elm.LocalName == "plan")
                {
                    this.Plan = new Plan(elm);
                }
            }
        }

        public XmlNode WriteXml(XmlDocument doc)
        {
            XmlElement node = doc.CreateElement(NameSpacePrefix, "problemItem", NameSpaceURI);

            XmlElement elm;

            if (Assessment.Count > 0)
            {
                elm = doc.CreateElement(NameSpacePrefix, "assessment", NameSpaceURI);
                foreach (string ai in Assessment)
                {
                    XmlElement elmChild = doc.CreateElement(NameSpacePrefix, "assessmentItem", NameSpaceURI);
                    elmChild.AppendChild(doc.CreateTextNode(ai));
                    elm.AppendChild(elmChild);
                }
                node.AppendChild(elm);
            }

            if (Problem != null)
            {
                node.AppendChild(Problem.WriteXml(doc));
            }

            if (Subjective != null)
            {
                node.AppendChild(Subjective.WriteXml(doc));
            }

            if (Objective != null)
            {
                node.AppendChild(Objective.WriteXml(doc));
            }

            if (Plan != null)
            {
                node.AppendChild(Plan.WriteXml(doc));
            }

            return node;
        }
    }
}