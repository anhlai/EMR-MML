﻿using System;
using System.Collections.Generic;

using System.Text;

namespace MedicalInterface {
    public class FacilityInfo {

        public string FacilityId { get; set; }

        public string FacilityName { get; set; }

        public string PostNumber { get; set; }

        public string AddressText { get; set; }

    }
}
