﻿namespace MedicalInterfaceTest
{
    using System;
    using System.Collections.Generic;

    using EmrDocker.Models;
    using EmrDocker.Types;

    using MedicalInterface;
    using MedicalInterface.Mml23;
    using MedicalInterface.Mml23.MmlPc;
    using MedicalInterface.Mml23.MmlPi;

    public class MmlParser
    {
        private readonly Dictionary<string, MmlStorage> TagStorage = new Dictionary<string, MmlStorage>();
        private static readonly MmlParser _instance = new MmlParser();

        private const string IMAGE_TOKEN = "$IMG$";
        private const string PDF_TOKEN = "$PDF$";

        public static MmlParser Instance
        {
            get
            {
                return _instance;
            }
        }

        private MmlParser()
        {
            TagStorage.Add("MA", MmlStorage.PROBLEM);
            TagStorage.Add("MI", MmlStorage.PROBLEM);
            TagStorage.Add("MS", MmlStorage.PROBLEM);

            TagStorage.Add("S", MmlStorage.SUBJECTIVE);
            TagStorage.Add("CC", MmlStorage.SUBJECTIVE);
            TagStorage.Add("CR", MmlStorage.SUBJECTIVE);
            TagStorage.Add("AN", MmlStorage.SUBJECTIVE);
            TagStorage.Add("DH", MmlStorage.SUBJECTIVE);
            TagStorage.Add("FH", MmlStorage.SUBJECTIVE);
            TagStorage.Add("LH", MmlStorage.SUBJECTIVE);
            TagStorage.Add("HH", MmlStorage.SUBJECTIVE);

            TagStorage.Add("O", MmlStorage.OBJECTIVE);
            TagStorage.Add("BM", MmlStorage.OBJECTIVE);
            TagStorage.Add("CO", MmlStorage.OBJECTIVE);
            TagStorage.Add("DF", MmlStorage.OBJECTIVE);
            TagStorage.Add("IF", MmlStorage.OBJECTIVE);
            TagStorage.Add("TF", MmlStorage.OBJECTIVE);

            TagStorage.Add("A", MmlStorage.ASSESSMENT);
            TagStorage.Add("AD", MmlStorage.ASSESSMENT);
            TagStorage.Add("CD", MmlStorage.ASSESSMENT);
            TagStorage.Add("LS", MmlStorage.ASSESSMENT);

            TagStorage.Add("P", MmlStorage.PLAN);
            TagStorage.Add("Tx", MmlStorage.PLAN);
            TagStorage.Add("Dx", MmlStorage.PLAN);
            TagStorage.Add("Ex", MmlStorage.PLAN);
            TagStorage.Add("Px", MmlStorage.PLAN);
            TagStorage.Add("Wx", MmlStorage.PLAN);
            TagStorage.Add("Np", MmlStorage.PLAN);
        }

        public Tuple<List<EmrRecordInfo>, PatientInfo> ToModel(string mml)
        {
            List<EmrRecordInfo> records = new List<EmrRecordInfo>();
            InterfaceFacade facade = new InterfaceFacade();
            PatientInfo patient = null;
            Mml doc = facade.ReadMml23(mml, false);

            if (doc != null && doc.Body != null && doc.Body.Modules.Count > 0)
            {
                foreach (MmlModuleItem mi in doc.Body.Modules)
                {
                    ProgressCourseModule module = mi.Content as ProgressCourseModule;
                    if (module != null)
                    {
                        EmrRecordInfo emrRecord = new EmrRecordInfo();
                        emrRecord.PkOut = mi.DocInfo.DocId;
                        if (mi.DocInfo.Creator != null && mi.DocInfo.Creator.Parson!=null)
                        {
                            emrRecord.HospCode = mi.DocInfo.Creator.Parson.Facility == null ? string.Empty : mi.DocInfo.Creator.Parson.Facility.Id.Text;
                            emrRecord.Facility = mi.DocInfo.Creator.Parson.Facility == null ? string.Empty : mi.DocInfo.Creator.Parson.Facility.Name;
                            emrRecord.Doctor = mi.DocInfo.Creator.Parson.ParsonId.Text;                            
                        }
                        emrRecord.DateTime = mi.DocInfo.ConfirmDate.ToString("yyyy-MM-dd");
                        foreach (ProblemItem pi in module.StructuredExpression)
                        {
                            foreach (string aItem in pi.Assessment)
                            {
                                emrRecord.TagInfos.Add(ParseTag(aItem));
                            }

                            if (pi.Problem != null)
                            {
                                emrRecord.TagInfos.Add(ParseTag(pi.Problem.Text));
                            }
                            if (pi.Subjective != null)
                            {
                                foreach (SubjectiveItem si in pi.Subjective.Items)
                                {
                                    foreach (string ee in si.EventExpression)
                                    {
                                        emrRecord.TagInfos.Add(ParseTag(ee));      
                                    }                                    
                                }                                
                            }
                            if (pi.Objective != null)
                            {
                                emrRecord.TagInfos.Add(ParseTag(pi.Objective.ObjectiveNotes));      
                            }
                            if (pi.Plan != null)
                            {
                                if (!string.IsNullOrEmpty(pi.Plan.PlanNotes))
                                {
                                    emrRecord.TagInfos.Add(ParseTag(pi.Plan.PlanNotes));     
                                }
                                if (pi.Plan.TxOrder != null)
                                {
                                    emrRecord.OrderInfos.AddRange(ParseOrders(pi.Plan.TxOrder.Text));
                                }
                            }
                        }
                        records.Add(emrRecord);
                    }
                    PatientModule patientModule = mi.Content as PatientModule;
                    if (patientModule != null)
                    {
                        patient = new PatientInfo();
                        if (patientModule.MasterId != null) patient.PatientId = patientModule.MasterId.Text;
                        patient.PatientBirthday = patientModule.Birthday.ToString("yyyy-MM-dd");
                        patient.PatientGender = patientModule.Sex;
                        patient.PatientAddress = patientModule.AddressList.Count == 0
                                                     ? null
                                                     : patientModule.AddressList[0].FullName;
                        patient.PatientZip = patientModule.AddressList.Count == 0
                                                     ? null
                                                     : patientModule.AddressList[0].Zip;
                        patient.PatientTelephone = patientModule.PhoneList.Count == 0
                                                       ? null
                                                       : patientModule.PhoneList[0].Memo;

                    }
                }
            }

            return new Tuple<List<EmrRecordInfo>, PatientInfo>(records, patient);
        }

        private IEnumerable<OrderInfo> ParseOrders(string orderText)
        {
            throw new System.NotImplementedException();
        }

        private TagInfo ParseTag(string content)
        {
            if (!string.IsNullOrEmpty(content))
            {
                TagInfo info = new TagInfo();
                info.Type = TypeEnum.Unknown;
                if (content.Trim().StartsWith(IMAGE_TOKEN, StringComparison.CurrentCultureIgnoreCase))
                {
                    info.Type = TypeEnum.Image;
                    info.DirLocation = content.Trim().Substring(IMAGE_TOKEN.Length);
                }
                else if (content.Trim().StartsWith(PDF_TOKEN, StringComparison.CurrentCultureIgnoreCase))
                {
                    info.Type = TypeEnum.Pdf;
                    info.DirLocation = content.Trim().Substring(PDF_TOKEN.Length);
                }
                else
                {
                    int index = content.Trim().IndexOf("#", 1, StringComparison.Ordinal);
                    if (index > 1)
                    {
                        info.Type = TypeEnum.Tag;
                        info.Content = content.Trim().Substring(index + 1).Trim();
                        info.TagCode = content.Trim().Substring(1, index - 1);
                    }
                }
                return info;
            }
            return null;
        }
        public string ToMmL(List<EmrRecordInfo> records, PatientInfo patient)
        {
            InterfaceFacade facade = new InterfaceFacade();
            
            Mml mml = facade.CreateMml23(patient.PatientId);
            foreach (EmrRecordInfo record in records)
            {
                MmlModuleItem pcmdlitm = mml.CreateProgressCourseModule(record.PkOut, record.HospCode, record.Facility, record.Doctor, record.DateTime);
                ProgressCourseModule pcdis = (ProgressCourseModule)pcmdlitm.Content;
                foreach (TagInfo info in record.TagInfos)
                {
                    MmlStorage storage = TagStorage.ContainsKey(info.TagCode)
                                             ? TagStorage[info.TagCode]
                                             : MmlStorage.PLAN;
                    ProblemItem item = new ProblemItem();
                    switch (storage)
                    {
                            case MmlStorage.ASSESSMENT:
                                item.Assessment.Add(ToMmlTag(info));
                                break;
                            case MmlStorage.OBJECTIVE:
                                item.Objective = new Objective();
                                item.Objective.ObjectiveNotes = ToMmlTag(info);
                                break;
                            case MmlStorage.PLAN:
                                item.Plan = new Plan();
                                item.Plan.PlanNotes = ToMmlTag(info);
                                break;
                            case MmlStorage.PROBLEM:
                                item.Problem = new Problem();
                                item.Problem.Text = ToMmlTag(info);
                                item.Problem.DxUid = DateTime.Now.Ticks.ToString();
                                break;
                            case MmlStorage.SUBJECTIVE:
                                item.Subjective = new Subjective();
                                SubjectiveItem si = new SubjectiveItem();
                                si.TimeExpression = DateTime.Now.ToString("yyyy-MM-dd");
                                si.EventExpression.Add(ToMmlTag(info));
                                item.Subjective.Items.Add(si);
                                break;
                    }
                    pcdis.StructuredExpression.Add(item);
                }
                if (record.OrderInfos.Count > 0)
                {
                    ProblemItem item = new ProblemItem();
                    item.Plan = new Plan();
                    item.Plan.TxOrder = new RxTxTestItem();
                    item.Plan.TxOrder.Text = ToOrderText(record.OrderInfos);
                }

                mml.Body.AddModuleItem(pcmdlitm);
            }
            return facade.WriteMml23(mml);
        }

        private string ToOrderText(List<OrderInfo> orderInfos)
        {
            throw new NotImplementedException();
        }

        private string ToMmlTag(TagInfo info)
        {
            switch (info.Type)
            {
                case TypeEnum.Tag:
                    return string.Format("#{0}# {1}", info.TagCode, info.Content);
                case TypeEnum.Image:
                    return string.Format("{0} {1}", IMAGE_TOKEN, info.DirLocation);
                case TypeEnum.Pdf:
                    return string.Format("{0} {1}", PDF_TOKEN, info.DirLocation);
                default:
                    return string.Empty;
            }
        }

        public enum MmlStorage
        {
            PROBLEM,
            SUBJECTIVE,
            OBJECTIVE,
            PLAN,
            ASSESSMENT
        }
    }
}