using System;

namespace EmrDocker.Models
{
    public class OrderInfo
    {
        private String _content;
        private String _gubunBass;
        private String _hangmogCode;
        private String _actionDoYn;
        private String _bunho;
        private String _doctor;
        private String _gwa;
        private String _naewonDate;
        private String _naewonKey;
        private String _inputTab;

        public String Content 
        {
            get { return _content; }
            set { _content = value; }
        }

        public String GubunBass
        {
            get { return _gubunBass; }
            set { _gubunBass = value; }
        }

        public String HangmogCode
        {
            get { return _hangmogCode; }
            set { _hangmogCode = value; }
        }

        public String ActionDoYn
        {
            get { return _actionDoYn; }
            set { _actionDoYn = value; }
        }

        public String Bunho
        {
            get { return _bunho; }
            set { _bunho = value; }
        }

        public String Doctor
        {
            get { return _doctor; }
            set { _doctor = value; }
        }

        public String Gwa
        {
            get { return _gwa; }
            set { _gwa = value; }
        }

        public String NaewonDate
        {
            get { return _naewonDate; }
            set { _naewonDate = value; }
        }

        public String NaewonKey
        {
            get { return _naewonKey; }
            set { _naewonKey = value; }
        }

        public String InputTab
        {
            get { return _inputTab; }
            set { _inputTab = value; }
        }

        public OrderInfo() { }

        public OrderInfo(String content, String gubunBass, String hangmogCode, String actionDoYn, String bunho, String doctor, String gwa, String naewonDate, String naewonKey, String inputTab)
        {
            _content = content;
            _gubunBass = gubunBass;
            _hangmogCode = hangmogCode;
            _actionDoYn = actionDoYn;
            _bunho = bunho;
            _doctor = doctor;
            _gwa = gwa;
            _naewonDate = naewonDate;
            _naewonKey = naewonKey;
            _inputTab = inputTab;
        }
    }
}