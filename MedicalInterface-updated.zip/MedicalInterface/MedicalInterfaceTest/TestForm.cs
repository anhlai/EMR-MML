﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MedicalInterface;
using MedicalInterface.Mml23;
using System.IO;
using System.Xml.Serialization;

namespace MedicalInterfaceTest {
    using EmrDocker.Models;
    using EmrDocker.Types;

    using MedicalInterface.Mml23.MmlCm;
    using MedicalInterface.Mml23.MmlPc;

    public partial class TestForm : Form {
        public TestForm() {
            InitializeComponent();
        }

        private void OrcaPatInfoReadTestButton_Click(object sender, EventArgs e)
        {
            string content = "#A# ";
            int index = content.Trim().IndexOf("#", 1, StringComparison.Ordinal);
            if (index > 1)
            {
                string ct = content.Trim().Substring(index + 1);
                string tc = content.Trim().Substring(1, index - 1);

            }


            InterfaceFacade facade = new InterfaceFacade();
            Mml doc = facade.ReadMml23("C:\\Users\\dainguyen\\Desktop\\Orca病名送信.xml", true);
//            Mml doc = facade.ReadMml23(Environment.CurrentDirectory + "\\TestFile\\Orca患者情報.xml");
            //Mml doc = facade.ReadMml23(Environment.CurrentDirectory + "\\TestFile\\0000000001.xml");
        }

        private void OrcaDiseaseCreateButton_Click(object sender, EventArgs e) {
            InterfaceFacade facade = new InterfaceFacade();
            facade.Facility = CreateFacilityInfo();
            facade.CreatorParson = CreateParsonInfo();
            
            Mml mml = facade.CreateMml23("90000001");

            var mdlitm = mml.CreateRegisteredDiagnosisModule();
            var dis = (MedicalInterface.Mml23.MmlRd.RegisteredDiagnosisModule)mdlitm.Content;
            dis.Diagnosis.Code = "123456789";
            dis.Diagnosis.System = "TEST";
            dis.Diagnosis.Text = "テスト病名";
            dis.StartDate = new DateTime(2010, 4, 2);

            mml.Body.AddModuleItem(mdlitm);

            mdlitm = mml.CreateRegisteredDiagnosisModule();
            dis = (MedicalInterface.Mml23.MmlRd.RegisteredDiagnosisModule)mdlitm.Content;

            var disitm = new MedicalInterface.Mml23.MmlRd.DiagnosisItem();
            disitm.Code = "123";
            disitm.System = "TEST";
            disitm.Text = "テスト接頭語";
            dis.DiagnosisContents.Add(disitm);

            disitm = new MedicalInterface.Mml23.MmlRd.DiagnosisItem();
            disitm.Code = "456";
            disitm.System = "TEST";
            disitm.Text = "テスト幹病名";
            dis.DiagnosisContents.Add(disitm);

            disitm = new MedicalInterface.Mml23.MmlRd.DiagnosisItem();
            disitm.Code = "789";
            disitm.System = "TEST";
            disitm.Text = "テスト接尾語";
            dis.DiagnosisContents.Add(disitm);

            dis.StartDate = new DateTime(2008, 8, 5);
            dis.EndDate = new DateTime(2009, 3, 16);
            dis.FirstEncounterDate = new DateTime(2006, 2, 25);

            dis.Outcome.Text = "recovering";

            //カテゴリはフラグに変換したほうがよい？

            mml.Body.AddModuleItem(mdlitm);

            //---------------------------------
            var pcmdlitm = mml.CreateProgressCourseModule();
            var pcdis = (MedicalInterface.Mml23.MmlPc.ProgressCourseModule)pcmdlitm.Content;
            ProblemItem item = new ProblemItem();
            item.Assessment.Add("item1");
            item.Assessment.Add("item2");
            item.Problem = new Problem();
            item.Problem.Text = "Prob";
            item.Problem.DxUid = "1234";
            item.Plan = new Plan();
            item.Plan.PlanNotes = "p note";
            item.Plan.RxOrder = new RxTxTestItem();
            item.Plan.RxOrder.Text = "Rx order note";
            ExternalReference refer = new ExternalReference();
            refer.ContentType = "text/plain";
            refer.Title = "title";
            refer.Reference = "http://vnexpress.net/";
            item.Plan.RxOrder.References.Add(refer);
            item.Objective = new Objective();
            item.Objective.ObjectiveNotes = "objective notes";
            PhysicalExamItem pe = new PhysicalExamItem();
            pe.Title = "PE Title";
            pe.Interpretation = "inter";
            item.Objective.PhysicalExamContents.Add(pe);            
            item.Subjective = new Subjective();
            item.Subjective.FreeNotes = "free note";
            SubjectiveItem sitem = new SubjectiveItem();
            sitem.TimeExpression = "2015-09-09";
            sitem.EventExpression.Add("First event");
            item.Subjective.Items.Add(sitem);
            pcdis.StructuredExpression.Add(item);

            mml.Body.AddModuleItem(pcmdlitm);
            //---------------------------------

            facade.WriteMml23(mml, "C:\\Users\\dainguyen\\Desktop\\Orca病名送信.xml");            
        }

        private FacilityInfo CreateFacilityInfo() {
            var fi = new FacilityInfo();

            fi.FacilityId = "JPN999999999999";
            fi.FacilityName = "医療法人　オルカ医院";
            fi.PostNumber = "113-0021";
            fi.AddressText = "東京都文京区本駒込２－２８－１６";

            return fi;
        }

        private ParsonInfo CreateParsonInfo() {
            var pi = new ParsonInfo();

            pi.ParsonalId = "1001";
            pi.KanjiFamilyName = "山田";
            pi.KanjiGivenName = "太郎";
            pi.KanaFamilyName = "ヤマダ";
            pi.KanaGivenName = "タロウ";
            pi.DepartmentCode = "01";
            pi.ProfessionCode = "doctor";

            return pi;
        }

        private void OrcaSampleReadTextButton_Click(object sender, EventArgs e) {
            InterfaceFacade facade = new InterfaceFacade();
            Mml doc = facade.ReadMml23(Environment.CurrentDirectory + "\\TestFile\\Orcaサンプル.xml", true);
            
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            PatientInfo patient = new PatientInfo(
                "1",
                "Name",
                "Kana",
                "1986-09-02",
                "Male",
                "Ha Noi",
                "10000",
                "+84904451221");
            List<EmrRecordInfo> records = new List<EmrRecordInfo>();
            EmrRecordInfo item = new EmrRecordInfo("K01", "THan Kinh", "2015-09-08", "Doctor", "10002", new List<TagInfo>(), new List<OrderInfo>());
            item.TagInfos.Add(new TagInfo(1, "A", "", "This is tag A", TypeEnum.Tag, "2015-09-08", null));
            item.TagInfos.Add(new TagInfo(2, "MI", "", "This is tag MI", TypeEnum.Tag, "2015-09-08", null));
            item.TagInfos.Add(new TagInfo(3, "S", "", "This is tag S", TypeEnum.Tag, "2015-09-08", null));
            item.TagInfos.Add(new TagInfo(4, "O", "", "This is tag O", TypeEnum.Tag, "2015-09-08", null));
            item.TagInfos.Add(new TagInfo(5, "P", "", "This is tag P", TypeEnum.Tag, "2015-09-08", null));

            item.TagInfos.Add(new TagInfo(6, "P", "", "This is tag P", TypeEnum.Image, "2015-09-08", @"C:\image.png"));
            item.TagInfos.Add(new TagInfo(7, "P", "", "This is tag P", TypeEnum.Pdf, "2015-09-08", @"c:\test.pdf"));

            item.TagInfos.Add(new TagInfo(8, "Dx", "", "This is tag P", TypeEnum.Tag, "2015-09-08", null));
            records.Add(item);
            //item.OrderInfos.Add(new OrderInfo());

            contentMml = MmlParser.Instance.ToMmL(records, patient);
        }

        private string contentMml = null;

        private void btnRead_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(contentMml))
            {
                Tuple<List<EmrRecordInfo>, PatientInfo> result = MmlParser.Instance.ToModel(contentMml);

            }
        }

    }
}
